//
//  MNPostJobVC.swift
//  Munka
//
//  Created by Amit on 26/11/19.
//  Copyright © 2019 Amit. All rights reserved.
//

import UIKit
import GooglePlaces
class MNPostJobVC: UIViewController,GetSelectCategoryOnPostJob {
    @IBOutlet weak var btnProfessional: UIButton!
    @IBOutlet weak var btnFreelancer: UIButton!
    @IBOutlet weak var btnHourly: UIButton!
    @IBOutlet weak var btnFixed: UIButton!
    @IBOutlet weak var btnUrgentFill: UIButton!
    @IBOutlet weak var btnIsPrivateLocation: UIButton!
    
    @IBOutlet weak var txtJoTitle: UITextField!
    @IBOutlet weak var txtSelectCategory: UITextField!
    @IBOutlet weak var txtViewJobDescriptions: UITextView!
    @IBOutlet weak var txtJobLocation: UITextField!
    @IBOutlet weak var txtFixedPrice: UITextField!
    @IBOutlet weak var txtStartDate: UITextField!
     @IBOutlet weak var txtEndDate: UITextField!
    @IBOutlet weak var txtStartTime: UITextField!
    @IBOutlet weak var txtEndTime: UITextField!
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var tbleView: UITableView!
    var isFixedSelected = false
    var isPaymentThrough = false
    var isHourlySelected = true
    var startTime = ""
    var endTime = ""
    var isProfessional = ""
    var isLocationPrivate = ""
    var isUrgentFill = ""
    var serviceCategory = ""
    var jobType = ""
    var strLatitude = ""
    var strLongitude = ""
    var startDate1 = Date()
    var endDate1 = Date()
    var stratTime = Date()
    var arrayDates = [[String:Any]]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btnProfessional.isSelected = true
        // Do any additional setup after loading the view.
        txtViewJobDescriptions.text = "Job Description…"
        txtViewJobDescriptions.textColor = UIColor.hexStringToUIColor(hex: "B1B1B1")
        txtStartDate.inputView = datePicker
        txtEndDate.inputView = datePicker
        txtStartTime.inputView = datePicker
        txtEndTime.inputView = datePicker
       
        
        datePicker.datePickerMode = UIDatePicker.Mode.date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMMM yyyy"
        datePicker.minimumDate = Calendar.current.date(byAdding: .day, value: +1, to: Date())
        
        isProfessional = "1"
        isLocationPrivate = "0"
        isUrgentFill = "0"
//         txtFixedPrice.addTarget(self, action: #selector(MNPostJobVC.textFieldDidChange(_:)), for: UIControl.Event.editingChanged)
    }
//    @objc func textFieldDidChange(_ textField: UITextField) {
//      let emailPred = NSPredicate(format:"SELF MATCHES %@", regexPassword)
//      //return emailPred.evaluate(with: passwordStr)
//
//        if  emailPred.evaluate(with: textField.text!){
//              imgRightconstarints.constant = 25
//              imgright.isHidden = false
//          }else{
//              imgRightconstarints.constant = 0
//              imgright.isHidden = true
//          }
//    }
    func delegateCategoryType(array: [[String : String]]) {
        
    }
//    func delegatePostJobcategory(array:[[String:Any]]){
//        if array.count > 0{
//            let dict = array[0]
//            self.txtSelectCategory.text = dict["name"] as? String
//            serviceCategory = dict["id"] as! String
//        }else{
//            self.txtSelectCategory.placeholder = "Select Category"
//        }
//        
//    }
    func delegateselectPostJobcategory(array:[[String:Any]]){
        let dict = array[0]
        self.txtSelectCategory.text = dict["name"] as? String
        serviceCategory = dict["id"] as! String
    }
    @IBAction func actionOnProfessoinal(_ sender: UIButton) {
        btnProfessional.isSelected = true
        btnFreelancer.isSelected = false
        isProfessional = "1"
    }
    @IBAction func actionOnFreelauncer(_ sender: UIButton) {
        btnProfessional.isSelected = false
        btnFreelancer.isSelected = true
        isProfessional = "2"
    }
    @IBAction func actionOnPaymentThrough(_ sender: UIButton) {
       txtStartDate.isEnabled = true
       txtEndDate.isEnabled = true
       txtEndTime.isEnabled = true
       txtStartTime.isEnabled = true
        switch sender.tag {
                case -98:
                    self.btnHourly.isSelected = true
                    self.btnFixed.isSelected = false
                    isPaymentThrough = false
                    isHourlySelected = true
                    self.stratTime = Date()
                    self.stratTime = Date()
                    self.endDate1 = Date()
                    self.startDate1 = Date()
                    self.txtStartDate.text = ""
                    self.txtEndDate.text = ""
                    self.txtStartTime.text = ""
                    self.txtEndTime.text = ""
                    self.btnHourly.layer.borderColor = UIColor.hexStringToUIColor(hex: "13C1B3").cgColor
                    self.txtFixedPrice.placeholder = "Enter hourly price"
                    self.btnFixed.layer.borderColor = UIColor.hexStringToUIColor(hex: "B1B1B1").cgColor
                    isFixedSelected =  false
                    jobType = "Hourly"
                    txtFixedPrice.text! = ""
                    txtFixedPrice.becomeFirstResponder()
//                    txtStartDate.becomeFirstResponder()
//                    txtEndDate.becomeFirstResponder()
//                    txtStartTime.becomeFirstResponder()
//                    txtEndTime.becomeFirstResponder()
                case -99:
                   self.btnHourly.isSelected = false
                   self.btnFixed.isSelected = true
                   isHourlySelected = false
                   isFixedSelected =  true
                   self.txtFixedPrice.placeholder = "Enter fixed price"
                   self.stratTime = Date()
                   self.stratTime = Date()
                   self.endDate1 = Date()
                   self.startDate1 = Date()
                   self.txtStartDate.text = ""
                   self.txtEndDate.text = ""
                   self.txtStartTime.text = ""
                   self.txtEndTime.text = ""
                   isPaymentThrough = true
                   self.btnFixed.layer.borderColor = UIColor.hexStringToUIColor(hex: "13C1B3").cgColor
                   self.btnHourly.layer.borderColor = UIColor.hexStringToUIColor(hex: "B1B1B1").cgColor
                   self.arrayDates = [[String:Any]]()
                   self.tbleView.reloadData()
                  isFixedSelected =  true
                    txtFixedPrice.text! = ""
                   jobType = "Fixed"
                   arrayDates = [[String:Any]]()
                   txtFixedPrice.becomeFirstResponder()
//                   txtStartDate.becomeFirstResponder()
//                   txtEndDate.becomeFirstResponder()
//                   txtStartTime.becomeFirstResponder()
//                   txtEndTime.becomeFirstResponder()
                default:
                    break
                }
    }
    @IBAction func actionOnPostJobs(_ sender: UIButton) {
        if !isPostJobValidation() {
            if  isConnectedToInternet() {
                if ((self.txtFixedPrice.text! == "0") || (self.txtFixedPrice.text! == "0.00") || (self.txtFixedPrice.text! == "00") || (self.txtFixedPrice.text! == ".0") || (self.txtFixedPrice.text! == ".00") || (self.txtFixedPrice.text! == "0.0") || (self.txtFixedPrice.text! == ".")) {
                    self.showErrorPopup(message: "Please enter valid amount.", title: alert)
                    }else{
                        self.callPostJobAPI()
                   }
                
                } else {
                self.showErrorPopup(message: internetConnetionError, title: alert)
            }
        }
    }
    @IBAction func actionOnSaveJobs(_ sender: UIButton) {
       if !isPostJobValidation() {
           if  isConnectedToInternet() {
            
           if ((self.txtFixedPrice.text! == "0") || (self.txtFixedPrice.text! == "0.00") || (self.txtFixedPrice.text! == "00") || (self.txtFixedPrice.text! == ".0") || (self.txtFixedPrice.text! == ".00") || (self.txtFixedPrice.text! == "0.0") || (self.txtFixedPrice.text! == ".")) {
               self.showErrorPopup(message: "Please enter valid amount.", title: alert)
            }else{
               self.callSaveJobAPI()
            }
        } else {
               self.showErrorPopup(message: internetConnetionError, title: alert)
           }
       }
       }
    func callPostJobAPI() {
        let parameter: [String: Any]
        if !isPaymentThrough {
            var arrayD = [String]()
            var arraySTime = [String]()
            var arrayETime = [String]()
            for items in self.arrayDates {
                let dict = items
                let dates = dict["dates"] as! String
                let start = dict["startTime"] as! String
                let end = dict["endTime"] as! String
                arrayD.append(self.convertMMMDDYYYYTOYYYYMMDD(dates))
                arraySTime.append(start)
                arrayETime.append(end)
                print(arrayD)
                print(arraySTime)
                print(arrayETime)
                
            }
            
            ShowHud(view: self.view)
            parameter = ["user_id":MyDefaults().UserId!,
               "mobile_auth_token":MyDefaults().UDeviceToken!,
               "job_title":self.txtJoTitle.text!,
               "job_description":self.txtViewJobDescriptions.text!,
               "job_type":jobType,
               "service_catagory":serviceCategory,
               "job_location":self.txtJobLocation.text!,
               "latitude":strLatitude,
               "longitude":strLongitude,
               "job_start_date":(self.convertMMMDDYYYYTOYYYYMMDD(self.txtStartDate.text!)),
               "job_end_date":(self.convertMMMDDYYYYTOYYYYMMDD(self.txtEndDate.text!)),
               "job_start_time":self.txtStartTime.text!,
               "job_end_time":self.txtEndTime.text!,
               "budget_amount":self.txtFixedPrice.text!,
               "is_professional":isProfessional,
               "is_publish":"1",
               "urgent_fill":isUrgentFill,
               "hourly_date":arrayD,
               "hourly_start_time":arraySTime,
               "hourly_end_time":arrayETime,
               "is_private" : isLocationPrivate
            ]
               
        }else{
            ShowHud(view: self.view)
            parameter = ["user_id":MyDefaults().UserId!,
               "mobile_auth_token":MyDefaults().UDeviceToken!,
               "job_title":self.txtJoTitle.text!,
               "job_description":self.txtViewJobDescriptions.text!,
               "job_type":jobType,
               "service_catagory":serviceCategory,
               "job_location":self.txtJobLocation.text!,
               "latitude":strLatitude,
               "longitude":strLongitude,
               "job_start_date":self.txtStartDate.text!,
               "job_end_date":self.txtEndDate.text!,
               "job_start_time":self.txtStartTime.text!,
               "job_end_time":self.txtEndTime.text!,
               "budget_amount":self.txtFixedPrice.text!,
               "is_professional":isProfessional,
               "is_publish":"1",
               "urgent_fill":isUrgentFill,
               "is_private" : isLocationPrivate
            ]
        }
        
        debugPrint(parameter)
         HTTPService.callForPostApi(url:MNPJobPostAPI , parameter: parameter) { (response) in
             debugPrint(response)
            print(response)
          HideHud(view: self.view)
            if response.count != nil
            {
                let status = response["status"] as! String
           if status == "1"
             {
                let message = response["msg"] as! String
                self.navigationController?.popViewController(animated: true)
                self.showAlert(title: ALERTMESSAGE, message: message)
            } else if status == "4"
            {
                let message = response["msg"] as! String
                self.autoLogout(title: ALERTMESSAGE, message: message)
           }
             else
             {
                let message = response["msg"] as! String
                 self.showErrorPopup(message: message, title: ALERTMESSAGE)
             }
              
        }  else{
            self.showErrorPopup(message: serverNotFound, title: ALERTMESSAGE)
                      }
            
        }
    }
    func callSaveJobAPI() {
        let parameter: [String: Any]
        if !isPaymentThrough {
            var arrayD = [String]()
            var arraySTime = [String]()
            var arrayETime = [String]()
            for items in self.arrayDates {
                let dict = items
                let dates = dict["dates"] as! String
                let start = dict["startTime"] as! String
                let end = dict["endTime"] as! String
               // arrayD.append(dates)
                arrayD.append(self.convertMMMDDYYYYTOYYYYMMDD(dates))
                arraySTime.append(start)
                arrayETime.append(end)
                
            }
            
            ShowHud(view: self.view)
            parameter = ["user_id":MyDefaults().UserId!,
               "mobile_auth_token":MyDefaults().UDeviceToken!,
               "job_title":self.txtJoTitle.text!,
               "job_description":self.txtViewJobDescriptions.text!,
               "job_type":jobType,
               "service_catagory":serviceCategory,
               "job_location":self.txtJobLocation.text!,
               "latitude":strLatitude,
               "longitude":strLongitude,
               "job_start_date":self.txtStartDate.text!,
               "job_end_date":self.txtEndDate.text!,
               "job_start_time":self.txtStartTime.text!,
               "job_end_time":self.txtEndTime.text!,
               "budget_amount":self.txtFixedPrice.text!,
               "is_professional":isProfessional,
               "is_publish":"2",
               "urgent_fill":isUrgentFill,
               "hourly_date":arrayD,
               "hourly_start_time":arraySTime,
               "hourly_end_time":arrayETime,
                "is_private" : isLocationPrivate]
               
        }else{
            ShowHud(view: self.view)
            parameter = ["user_id":MyDefaults().UserId!,
               "mobile_auth_token":MyDefaults().UDeviceToken!,
               "job_title":self.txtJoTitle.text!,
            "job_description":self.txtViewJobDescriptions.text!,
               "job_type":jobType,
               "service_catagory":serviceCategory,
               "job_location":self.txtJobLocation.text!,
               "latitude":strLatitude,
               "longitude":strLongitude,
               "job_start_date":self.txtStartDate.text!,
               "job_end_date":self.txtEndDate.text!,
               "job_start_time":self.txtStartTime.text!,
               "job_end_time":self.txtEndTime.text!,
               "budget_amount":self.txtFixedPrice.text!,
               "is_professional":isProfessional,
               "is_publish":"2",

               "urgent_fill":isUrgentFill,
               "is_private" : isLocationPrivate
              // "user_type":MyDefaults().swiftUserData!["user_type"]!
               ]
        }
        
        debugPrint(parameter)
         HTTPService.callForPostApi(url:MNPJobPostAPI , parameter: parameter) { (response) in
             debugPrint(response)
          HideHud(view: self.view)
            if response.count != nil {
            let status = response["status"] as! String
             let message = response["msg"] as! String
             if status == "1"
             {
                
                self.navigationController?.popViewController(animated: true)
                self.showAlert(title: ALERTMESSAGE, message: message)
            } else if status == "4"
            {
                self.autoLogout(title: ALERTMESSAGE, message: message)
             }
             else
             {
                 self.showErrorPopup(message: message, title: ALERTMESSAGE)
            }}else
            {
                self.showErrorPopup(message: serverNotFound, title: ALERTMESSAGE)
            }
            
         }
    }
   
    @IBAction func actionOnBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func actionOnUrgentFill(_ sender: UIButton) {
        if btnUrgentFill.isSelected {
              self.btnUrgentFill.isSelected = false
                isUrgentFill = "0"
          }else {
        self.btnUrgentFill.isSelected = true
                isUrgentFill = "1"
          }
    }
    @IBAction func actionOnIsprivateLocation(_ sender: UIButton) {
       if btnIsPrivateLocation.isSelected {
              self.btnIsPrivateLocation.isSelected = false
        print("false")
            isLocationPrivate = "0"
          }else {
        self.btnIsPrivateLocation.isSelected = true
             print("true")
            isLocationPrivate = "1"
          }
    }
    @IBAction func actionOnJobLocation(_ sender: UIButton) {
        let placePickerController = GMSAutocompleteViewController()
        let searchBarTextAttributes: [NSAttributedString.Key : AnyObject] = [NSAttributedString.Key(rawValue: NSAttributedString.Key.foregroundColor.rawValue): UIColor.white, NSAttributedString.Key(rawValue: NSAttributedString.Key.font.rawValue): UIFont.systemFont(ofSize: UIFont.systemFontSize)]
        UITextField.appearance(whenContainedInInstancesOf: [UISearchBar.self]).defaultTextAttributes = searchBarTextAttributes
                       placePickerController.delegate = self
                       present(placePickerController, animated: true, completion: nil)
                       self.popupAlert(title: "Title", message: " Oops, xxxx ", actionTitles: ["Option1","Option2","Option3"], actions:[{action1 in
               
                           },{action2 in
               
                           }, nil])
    }
    @IBAction func actionOnSelectCategory(_ sender: UIButton) {
       
        let popup : PostJobSelectcategoryPopUpVC = storyBoard.PopUp.instantiateViewController(withIdentifier: "PostJobSelectcategoryPopUpVC") as! PostJobSelectcategoryPopUpVC
            popup.delagate = self
//        popup.isClickOnSignUp = false
        self.presentOnRoot(with: popup)
    }
    func isPostJobValidation() -> Bool {
        guard let jobTitle = txtJoTitle.text , jobTitle != ""
            else {showAlert(title: "Alert", message: "Please enter job title.")
                return true}
        guard let selectCategory = txtJoTitle.text , selectCategory != ""
        else {showAlert(title: "Alert", message: "Please enter category.")
            return true}
        guard let jobDescriptions = txtViewJobDescriptions.text , jobDescriptions != ""
               else {showAlert(title: "Alert", message: "Please enter job description.")
                   return true}
        guard let jobLocation = txtJobLocation.text , jobLocation != ""
        else {showAlert(title: "Alert", message: "Please enter job location.")
            return true}
         guard isFixedSelected == true || isHourlySelected == true else {showAlert(title: "Alert", message: "Please select payment through.")
                     return true
                 }
       guard let enterFixedPrice = txtFixedPrice.text , enterFixedPrice != ""
              else {showAlert(title: "Alert", message: "Please enter price.")
                  return true}
        guard let startDate = txtStartDate.text , startDate != ""
        else {showAlert(title: "Alert", message: "Please enter date.")
            return true}
        guard let endDate = txtEndDate.text , endDate != ""
               else {showAlert(title: "Alert", message: "Please enter date.")
                   return true}
        guard let startTime = txtStartTime.text , startTime != ""
        else {showAlert(title: "Alert", message: "Please enter time.")
            return true}
        guard let endTime = txtEndTime.text , endTime != ""
               else {showAlert(title: "Alert", message: "Please enter time.")
                   return true}
        return false
    }
}
extension MNPostJobVC:UITextViewDelegate,UITextFieldDelegate,GetCallDelegateOfTextField{
    
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == UIColor.hexStringToUIColor(hex: "B1B1B1") {
            textView.text = nil
            textView.textColor = UIColor.hexStringToUIColor(hex: "7E8290")
        }
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = "Job Description…"
            textView.textColor = UIColor.hexStringToUIColor(hex: "B1B1B1")
        }
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
           if !isFixedSelected && !isHourlySelected{
            textField.resignFirstResponder()
            self.showAlert(title: "Please Select payment through.", message: ALERTMESSAGE)
           }else{
        if textField == txtStartDate {
                let formatter = DateFormatter()
                formatter.dateFormat = "MMM dd, yyyy"
                txtStartDate.text = formatter.string(from: datePicker.date)
                startDate1 = datePicker.date
                txtEndDate.text = ""
                self.endDate1 = Date()
            }
            else if textField == txtEndDate {
                let formatter = DateFormatter()
                formatter.dateFormat = "MMM dd, yyyy"
                txtEndDate.text = formatter.string(from: datePicker.date)
                endDate1 = datePicker.date
            }
            else if textField == txtStartTime {
                let formatter = DateFormatter()
                formatter.dateFormat = "HH:mm"
                txtStartTime.text = formatter.string(from: datePicker.date)
                startTime = txtStartTime.text!
                self.stratTime = formatter.date(from: txtStartTime.text!)!
                txtEndTime.text = ""
                self.endTime = ""
                print(txtStartTime.text!)
            }
            else if textField == txtEndTime {
                let formatter = DateFormatter()
                formatter.dateFormat = "HH:mm"
                txtEndTime.text = formatter.string(from: datePicker.date)
                endTime = txtEndTime.text!
            if self.isHourlySelected{
                 self.getMultipleDates()
            }else{
                
            }
          }
        }
       }
    //MARK:- Date Picker
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if !isFixedSelected && !isHourlySelected{
            txtFixedPrice.resignFirstResponder()
            txtStartDate.resignFirstResponder()
            txtEndDate.resignFirstResponder()
            txtStartTime.resignFirstResponder()
            txtEndTime.resignFirstResponder()
            self.showAlert(title: "Please Select payment through.", message: ALERTMESSAGE)
        }else{
            
         if textField == txtStartDate {
            datePicker.datePickerMode = UIDatePicker.Mode.date
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "dd MMMM yyyy"
                datePicker.minimumDate = Calendar.current.date(byAdding: .day, value: +1, to: Date())
                datePicker.maximumDate = .none
            }else if textField == txtEndDate {
            datePicker.datePickerMode = UIDatePicker.Mode.date
            if isHourlySelected{
                datePicker.minimumDate = self.startDate1
                datePicker.maximumDate = Calendar.current.date(byAdding: .day, value: +15, to: self.startDate1)
            }else{
                datePicker.minimumDate = self.startDate1
                datePicker.maximumDate = Calendar.current.date(byAdding: .day, value: +60, to: self.startDate1)
            }
            }else if textField == txtStartTime {
            datePicker.datePickerMode = UIDatePicker.Mode.time
           
         }
            else if textField == txtEndTime {
            datePicker.datePickerMode = UIDatePicker.Mode.time
            datePicker.minimumDate = self.stratTime
            }

        }
        }
    func getMultipleDates() {
      arrayDates = [[String:Any]]()
        // var Date1 = Date()
        let datesBetweenArray = Date.dates(from: startDate1, to: endDate1)
        for i in 0..<datesBetweenArray.count{
            var dict = [String:Any]()
           
            let getDate = datesBetweenArray[i]
            print(getDate)
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
            let dateString = dateFormatter.string(from: getDate)
            let newDates = self.extensionChangeDateFormat(dateString)
            print(newDates)
            dict["dates"] = newDates
            dict["startTime"] = startTime
            dict["endTime"] = endTime
            dict["fullformat"] = dateString
            arrayDates.append(dict)
            tbleView.reloadData()
        }
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
         if isPaymentThrough {
        if txtFixedPrice == textField
            {
                if textField.text?.count == 0 && string == "."
                {
                    return false
                }
                
                if textField.text == "0" && string == "0"
                {
                    return false
                }
                
                let amountString: NSString = textField.text! as NSString
                let newString: NSString = amountString.replacingCharacters(in: range, with: string) as NSString
                let regex = "\\d{0,4}(\\.\\d{0,2})?"
                
                let predicate = NSPredicate(format: "SELF MATCHES %@", regex)
                return predicate.evaluate(with:newString)
            }
         }else{
            if txtFixedPrice == textField
            {
                if textField.text?.count == 0 && string == "."
                {
                    return false
                }
                
                if textField.text == "0" && string == "0"
                {
                    return false
                }
                
                let amountString: NSString = textField.text! as NSString
                let newString: NSString = amountString.replacingCharacters(in: range, with: string) as NSString
                let regex = "\\d{0,2}(\\.\\d{0,2})?"
                
                let predicate = NSPredicate(format: "SELF MATCHES %@", regex)
                return predicate.evaluate(with:newString)
            }
        }
//       if !isPaymentThrough {
//        if let text = textField.text as NSString? {
//            let txtAfterUpdate = text.replacingCharacters(in: range, with: string)
//            let regex = try? NSRegularExpression(pattern: "^\\d{0,2}(\\.\\d{0,2})?$", options: [])
//                        return regex?.firstMatch(in: txtAfterUpdate, options: [], range: NSRange(location: 0, length: txtAfterUpdate.count)) != nil
//                    
//                    }
//                    return true
//        }else
//            if isPaymentThrough {
//            if let text = textField.text as NSString? {
//            let txtAfterUpdate = text.replacingCharacters(in: range, with: string)
//            let regex = try? NSRegularExpression(pattern: "^\\d{0,4}(\\.\\d{0,2})?$", options: [])
//            return regex?.firstMatch(in: txtAfterUpdate, options: [], range: NSRange(location: 0, length: txtAfterUpdate.count)) != nil
//                }
//            return true
//        }
        return true
    
    }
    
}
    
extension MNPostJobVC: GMSAutocompleteViewControllerDelegate {
    
    // Handle the user's selection.
    func viewController(_ viewController: GMSAutocompleteViewController, didAutocompleteWith place: GMSPlace) {
        print("Place name: \(place.name)")
        print("Place address: \(place.formattedAddress)")
        print("Place attributions: \(place.attributions)")
        var dLatitude = place.coordinate.latitude
        var dLongitude = place.coordinate.longitude
        strLatitude = String(dLatitude)
        strLongitude = String(dLongitude)
        self.txtJobLocation.text = place.name!
        dismiss(animated: true, completion: nil)
    }
    
    func viewController(_ viewController: GMSAutocompleteViewController, didFailAutocompleteWithError error: Error) {
        // TODO: handle the error.
        print("Error: ", error.localizedDescription)
    }
    
    // User canceled the operation.
    func wasCancelled(_ viewController: GMSAutocompleteViewController) {
        dismiss(animated: true, completion: nil)
    }
    
    // Turn the network activity indicator on and off again.
    func didRequestAutocompletePredictions(_ viewController: GMSAutocompleteViewController) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
    }
    
    func didUpdateAutocompletePredictions(_ viewController: GMSAutocompleteViewController) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
    }
    
}

extension MNPostJobVC: UITableViewDataSource,UITableViewDelegate{
    // MARK: - Delegate method for table view
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return self.objIndividual.count
        return arrayDates.count
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell : PostJobHourlyTableViewCell?
        cell = tableView.dequeueReusableCell(withIdentifier: "PostJobHourlyTableViewCell", for: indexPath) as? PostJobHourlyTableViewCell
        let dict = arrayDates[indexPath.row]
        cell?.lblDates.text   = dict["dates"] as? String
        cell?.txtEndTime.tag = indexPath.row + 1000
        cell?.txtStartTime.tag = indexPath.row
        cell?.txtEndTime.tag = indexPath.row + 1000
        cell?.txtStartTime.text   = dict["startTime"] as? String
        cell?.txtStartTime.inputView = datePicker
        cell?.txtEndTime.text   = dict["endTime"] as? String
        cell?.txtEndTime.inputView = datePicker
        //      cell?.txtEndTime.addTarget(self, action: #selector(MNPostJobVC.textFieldDidChange(_:)), for: UIControl.Event.editingChanged)
        cell?.delagate = self
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //         let details = self.storyboard?.instantiateViewController(withIdentifier: "MNPostDetailVC") as! MNPostDetailVC
        //        details.strJobId = self.objIndividual[indexPath.row].id
        //        self.navigationController?.pushViewController(details, animated: true)
        
    }
    
    func delegateDidBeginEditing(txtFiled: String, TagTextFiled: Int) {
        //        let dictall1 = self.arrayDates[TagTextFiled]
        //
        //        let dateString = dictall1["dates"] as! String
        //        let dateString = dictall1["dates"] as! String
        //        var date1 = dateString
        //        let AddTime = date1 +
        
        
        //  var date2 = dateString
        //   print(date1)
        var dict = [String:Any]()
        datePicker.datePickerMode = UIDatePicker.Mode.time
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        if txtFiled == "Start" {
            let time = formatter.string(from: datePicker.date)
            dict["startTime"] = time
            let dictall = self.arrayDates[TagTextFiled]
            let dates = dictall["dates"] as! String
            let end = dictall["endTime"] as! String
            let dateString = dictall["fullformat"] as! String
            dict["startTime"] = time
            dict["endTime"] = end
            dict["dates"] = dates
            dict["fullformat"] = dateString
            let addDates1 = dates + " " + time
            let addDates2 = dates +  " " + end
            
            print(addDates1)
            print(addDates2)
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd/M/yyyy, HH:mm"
            // let s = dateFormatter.date(from: addDates1)
            
            
            
            self.arrayDates[TagTextFiled] = dict
        }else{
            let end = formatter.string(from: datePicker.date)
            let dictall = self.arrayDates[TagTextFiled]
            let dates = dictall["dates"] as! String
            let start = dictall["startTime"] as! String
            let dateString = dictall["fullformat"] as! String
            dict["startTime"] = start
            dict["endTime"] = end
            dict["dates"] = dates
            dict["fullformat"] = dateString
            self.arrayDates[TagTextFiled] = dict
        }
        let indexPath = NSIndexPath(row: TagTextFiled, section: 0)
        tbleView.reloadRows(at: [(indexPath as IndexPath)], with: UITableView.RowAnimation.top)
        //tbleView.reloadData()
    }
    
    
    func comaperTime(time1:Date,time2:Date,rowNumber:Int) {
        let difference = Calendar.current.dateComponents([.hour, .minute], from: time1, to: time2)
        let formattedString = String(format: "%02ld%02ld", difference.hour!, difference.minute!)
        print(formattedString)
    }
}
extension Date {
    static func dates(from fromDate: Date, to toDate: Date) -> [Date] {
        var dates: [Date] = []
        var date = fromDate

        while date <= toDate {
            dates.append(date)
            guard let newDate = Calendar.current.date(byAdding: .day, value: 1, to: date) else { break }
            date = newDate
        }
        return dates
    }
}
