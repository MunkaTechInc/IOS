//
//  MNLoginVC.swift
//  Munka
//
//  Created by Amit on 08/11/19.
//  Copyright © 2019 Amit. All rights reserved.
//

import UIKit
import Toaster
import GoogleSignIn

import FBSDKLoginKit
class MNLoginVC: UIViewController, GIDSignInDelegate,GetUserType {
    @IBOutlet weak var txtEmail: DTTextField!
    @IBOutlet weak var txtPassword: DTTextField!
    @IBOutlet weak var btnRememberMe: UIButton!
   
 let firstNameMessage        = NSLocalizedString("Email is required.", comment: "")
 let lastNameMessage         = NSLocalizedString("Last name is required.", comment: "")
 let emailMessage            = NSLocalizedString("Email is required.", comment: "")
 let passwordMessage         = NSLocalizedString("Password is required.", comment: "")
 let confirmPasswordMessage  = NSLocalizedString("Confirm password is required.", comment: "")
 let mismatchPasswordMessage = NSLocalizedString("Password and Confirm password are not matching.", comment: "")
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

//        txtEmail.text = "ricky@mailinator.com"
//        txtPassword.text = "qwert@1"
        
        // Individual user
//        txtEmail.text = "iosindividual@mailinator.com"
//        txtPassword.text = "qwert@1"
        
        // freelancer user
//        txtEmail.text = "iosindividual@mailinator.com"
//        txtPassword.text = "qwert@1"

        
        
        GIDSignIn.sharedInstance()?.presentingViewController = self
        // Automatically sign in the user.
        GIDSignIn.sharedInstance()?.restorePreviousSignIn()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
         self.navigationController?.isNavigationBarHidden = false
        UINavigationBar.appearance().barTintColor = .black
        UINavigationBar.appearance().tintColor = .white
        UINavigationBar.appearance().titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        UINavigationBar.appearance().isTranslucent = false
        if MyDefaults().swiftRememberMe == true {
            txtEmail.text! = MyDefaults().UserEmail
            txtPassword.text! = MyDefaults().UserPassword
            btnRememberMe.isSelected = true
            
        }else{
            btnRememberMe.isSelected = false
        }
     
    }
    override func viewDidDisappear(_ animated: Bool) {
        
       
        
    }
    // MARK : IBAction Methods
    
    @IBAction func actionOnRememberMe(_ sender: UIButton) {
        //  sender.isSelected = !sender.isSelected
        if sender.isSelected {
            sender.isSelected = false
            MyDefaults().swiftRememberMe = false
        }else {
            sender.isSelected = true
            MyDefaults().swiftRememberMe = true
            MyDefaults().UserEmail = txtEmail.text!
            MyDefaults().UserPassword = txtPassword.text!
        }
    }
    @IBAction func actionOnForgotPassword(_ sender: UIButton) {
       // let vc = MNForgotPasswordVC() //change this to your class name
       // self.present(vc, animated: true, completion: nil)
        let forgot = self.storyboard?.instantiateViewController(withIdentifier: "MNForgotPasswordVC") as! MNForgotPasswordVC
        self.navigationController?.pushViewController(forgot, animated: true)
    }
    @IBAction func actionOnGoogleSignUp(_ sender: UIButton) {
        
        GIDSignIn.sharedInstance().signOut()
        GIDSignIn.sharedInstance().signIn()
        GIDSignIn.sharedInstance().delegate = self
       // GIDSignIn.sharedInstance()?.presentingViewController
        
    }
    @IBAction func actionOnSIgnIn(_ sender: UIButton) {
    if !isLoginValidation() {
        if  isConnectedToInternet() {
            
           MyDefaults().UserEmail = txtEmail.text!
           MyDefaults().UserPassword = txtPassword.text!
            MyDefaults().swifLoginType = "email"
            self.callServiceLoginAPI(email: "", password: "", facebookId: "", googleId: "")
        } else {
            self.showErrorPopup(message: internetConnetionError, title: alert)
        }
    }
    }
    @IBAction func actionOnSIgnUP(_ sender: UIButton) {
        let popup : WelcomePopupVC = storyBoard.PopUp.instantiateViewController(withIdentifier: "WelcomePopupVC") as! WelcomePopupVC
        popup.delagate = self
        self.presentOnRoot(with: popup)
    }
    @IBAction func actionOnfacebook(_ sender: UIButton) {
      
        if AccessToken.current != nil {
            self.getFBUserData()
            return
        }
        
        let fbLoginManager : LoginManager = LoginManager()
        LoginManager().logOut()
        fbLoginManager.logIn(permissions: ["public_profile","email"], from: self) { (result, error) -> Void in
            if (error == nil){
                let fbloginresult : LoginManagerLoginResult = result!
                
                if (result?.isCancelled)!{
                    return
                }
                if(fbloginresult.grantedPermissions.contains("email")) {
                    self.getFBUserData()
                }
            }
        }
}
    func socilLoginPopUp()  {
        let popup : WelcomePopupVC = storyBoard.PopUp.instantiateViewController(withIdentifier: "WelcomePopupVC") as! WelcomePopupVC
        popup.delagate = self
        self.presentOnRoot(with: popup)
    }
    func isLoginValidation() -> Bool {
         guard !txtEmail.text!.isEmptyStr else {
                   txtEmail.showError(message: firstNameMessage)
                   return true
               }
        guard let password = txtPassword.text , password != ""
                   else {showAlert(title: ALERTMESSAGE, message: "Please enter password.")
                       return true}
        return false
    }
    func callServiceLoginAPI(email:String,password:String,facebookId:String,googleId:String) {
       ShowHud(view: self.view)
       let parameter: [String: Any] = ["login_type":MyDefaults().swifLoginType!,
                                       "device_id":MyDefaults().UDeviceId ?? "343434343",
                                     "device_type":C_device_type,
                                     "fb_id":facebookId,
                                     "google_id":googleId,
                                     "password":txtPassword.text!,
                                     "email":txtEmail.text!]
        //debugPrint(parameter)
        HTTPService.callForPostApi(url:MNLoginAPI , parameter: parameter) { (response) in
            debugPrint(response)
         HideHud(view: self.view)
            if response.count != nil {
            let status = response["status"] as! String
            let message = response["msg"] as! String
            if status == "1"
            {
                let responseData = response["details"] as! [String: Any]
              if status == "1" && message == "Login Successfully"
              {
                
                MyDefaults().UserId = responseData["user_id"] as? String
                MyDefaults().UDeviceToken = responseData["mobile_auth_token"] as? String
                MyDefaults().swifSavePassword = self.txtPassword.text
                MyDefaults().swiftUserData = responseData as NSDictionary
                 if let tabbar = (storyBoard.tabbar.instantiateViewController(withIdentifier: "tabbar") as? MainTabbarVC) {
                     self.navigationController?.isNavigationBarHidden = true
                    tabbar.selectedIndex = 2
                    self.navigationController?.pushViewController(tabbar, animated: true)
                   // self.navigationController?.navigationBar.isHidden = true
                   
                   
                    //  self.present(tabbar, animated: true, completion: nil)
                   //  Toast(text: message).show()
                 }
              }else if responseData["mobile_verified"] as? String == "2" && message == "Your account is not verified yet, one-time verification code sent on your registered email address and mobile number."
              {
                    self.pushVerificationScreen(verifyScreen: "Mobile")
              }
              else if responseData["email_verified"] as? String == "2" && message == "Your account is not verified yet, one-time verification code sent on your registered email address."
              {
                self.pushVerificationScreen(verifyScreen: "")
            }
                }
            else
            {
                self.showErrorPopup(message: message, title: alert)
                }}else{
                    self.showErrorPopup(message: serverNotFound, title: alert)
        }
            
        }
    }
    func pushVerificationScreen(verifyScreen:String) {
        if verifyScreen == "Mobile"{
            let mobile = self.storyboard?.instantiateViewController(withIdentifier: "MNMobileVarificationVC") as! MNMobileVarificationVC
                   self.navigationController?.pushViewController(mobile, animated: true)
        }else{
            let mobile = self.storyboard?.instantiateViewController(withIdentifier: "MNEmailVerificationVC") as! MNEmailVerificationVC
                   self.navigationController?.pushViewController(mobile, animated: true)
        }
}
    func getFBUserData(){
        ShowHud(view: self.view)
        if(AccessToken.current != nil){
            GraphRequest(graphPath: "me", parameters: ["fields": "id,name , first_name, last_name , email,picture.type(large)"]).start(completionHandler: { (connection, result, error) in
                guard let Info = result as? [String: Any] else { return }
                
                if let imageURL = ((Info["picture"] as? [String: Any])?["data"] as? [String: Any])?["url"] as? String {
                    //Download image from imageURL
                   // print(imageURL)
                }
                let strName = Info["name"] as! String
                let strFirstName = Info["first_name"] as! String
                let last_name = Info["last_name"] as! String
                let userId = Info["id"] as! String
                let email = Info["email"] as! String
                MyDefaults().swiftGoolelData = nil
                MyDefaults().swiftFacebookData = Info as NSDictionary
               // self.callServiceLoginLoginAPI(email: email, password: "", facebookId: userId, googleId: "")
                
               // print(imageURL)
                MyDefaults().swifLoginType = "facebook"
                
                HideHud(view: self.view)
                self.socilLoginPopUp()
                if(error == nil){
                   // print("result")
                }
            })
        }
        
    }
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
     //  ShowHud(view: self.view)
        if let error = error {
            if (error as NSError).code == GIDSignInErrorCode.hasNoAuthInKeychain.rawValue {
                print("The user has not signed in before or they have since signed out.")
            } else {
                print("\(error.localizedDescription)")
            }
            return
        }
        // Perform any operations on signed in user here.
//        let userId = user.userID!                  // For client-side use only!
//        let idToken = user.authentication.idToken // Safe to send to the server
//        let fullName = user.profile.name
//        let givenName = user.profile.givenName
//        let familyName = user.profile.familyName
//         let email = user.profile.email
        
       
        
        MyDefaults().swiftFacebookData = nil
        HideHud(view: self.view)
        
        let fullNameArr = user.profile.name.components(separatedBy: " ")
        let firstName: String = fullNameArr[0]
        // var lastName: String = fullNameArr[1]
        let last_Name: String? = fullNameArr.count > 1 ? fullNameArr[1] : nil
        MyDefaults().swifLoginType = "google"
        var dictionary =  [String:String]()
        
        if firstName.isEmpty {
            dictionary.updateValue("", forKey: "first_name")
        }else{
            dictionary.updateValue(firstName, forKey: "first_name")
        }
        if let  last_Name = last_Name,last_Name.isEmpty  {
            dictionary.updateValue("", forKey: "last_name")
        }else{
            dictionary.updateValue(last_Name ?? "", forKey: "last_name")
        }
        if user.profile.email.isEmpty {
            dictionary.updateValue("", forKey: "email")
        }else{
            dictionary.updateValue(user.profile.email, forKey: "email")
        }
        if user.userID! .isEmpty {
            dictionary.updateValue(user.userID , forKey: "id")
        }else{
            dictionary.updateValue(user.userID, forKey: "id")
        }
        MyDefaults().swiftGoolelData = dictionary as NSDictionary
        
        self.socilLoginPopUp()
     
 }
    func sign(_ signIn: GIDSignIn!,dismiss viewController: UIViewController!) {
       
        self.dismiss(animated: true, completion: nil)
    }
    func sign(_ signIn: GIDSignIn!, didDisconnectWith user: GIDGoogleUser!,
              withError error: Error!) {
      // Perform any operations when the user disconnects from app here.
      // ...
    }
    // MARK: -  Custom Delegate Methods
    func DelegateUserType(UserType:Int){
        switch UserType {
        case 101:
            let vc = storyBoard.Main.instantiateViewController(withIdentifier: "MNIndividualSignupVC") as! MNIndividualSignupVC
              self.navigationController?.pushViewController(vc, animated: true)
        case 102:
            let vc = storyBoard.Main.instantiateViewController(withIdentifier: "MNProfessionalSignupVC") as! MNProfessionalSignupVC
            self.navigationController?.pushViewController(vc, animated: true)
            
        default:
            // executable code
            break
        }
    }
}


//MARK:- text Filed Delegate
extension MNLoginVC: UITextFieldDelegate {

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case txtEmail:
            txtPassword.becomeFirstResponder()
        case txtPassword:
            txtPassword.resignFirstResponder()
        default:
            break
        }
        return true
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == self.txtEmail {
            
        }
       else if textField == self.txtPassword {
            if self.txtEmail.text?.count == 0 {
                txtPassword.resignFirstResponder()
            }else{
                txtPassword.becomeFirstResponder()
            }
        }
    }
    
}
